public class FinancialForecasting {

    public static double calculateFutureValue(double initialValue, double[] growthRates, int year) {

        if (year == growthRates.length) {
            return initialValue;
        }

        double nextValue = initialValue * (1 + growthRates[year]);
        return calculateFutureValue(nextValue, growthRates, year + 1);
    }

    public static void main(String[] args) {

        double initialValue = 1000.0;
        double[] growthRates = { 0.05, 0.1, -0.02, 0.07 };

        double futureValue = calculateFutureValue(initialValue, growthRates, 0);
        System.out.println("Predicted Future Value: " + futureValue);
    }
}
