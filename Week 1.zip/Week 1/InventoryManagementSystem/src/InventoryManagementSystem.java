public class InventoryManagementSystem {

    public static void main(String[] args) {
        // Create an Inventory instance
        Inventory inventory = new Inventory();

        // Create some products
        Product product1 = new Product("P001", "Laptop", 10, 799.99);
        Product product2 = new Product("P002", "Smartphone", 20, 399.99);
        Product product3 = new Product("P003", "Tablet", 15, 299.99);

        // Add products to the inventory
        inventory.addProduct(product1);
        inventory.addProduct(product2);
        inventory.addProduct(product3);

        // Display a product
        System.out.println("Retrieved: " + inventory.getProduct("P001"));

        // Update a product
        Product updatedProduct = new Product("P001", "Laptop", 8, 749.99);
        inventory.updateProduct(updatedProduct);

        // Display the updated product
        System.out.println("Retrieved: " + inventory.getProduct("P001"));

        // Delete a product
        inventory.deleteProduct("P002");

        // Attempt to retrieve the deleted product
        System.out.println("Retrieved: " + inventory.getProduct("P002"));
    }
}
