import java.util.Arrays;

public class OrderSortingDemo {

    public static void main(String[] args) {
        // Create sample orders
        Order[] orders = {
                new Order("O001", "Alice", 250.00),
                new Order("O002", "Bob", 100.00),
                new Order("O003", "Charlie", 150.00),
                new Order("O004", "David", 300.00),
                new Order("O005", "Eve", 200.00)
        };

        // Display unsorted orders
        System.out.println("Unsorted Orders:");
        displayOrders(orders);

        // Bubble sort
        Order[] bubbleSortedOrders = Arrays.copyOf(orders, orders.length);
        SortingAlgorithms.bubbleSort(bubbleSortedOrders);
        System.out.println("\nBubble Sorted Orders:");
        displayOrders(bubbleSortedOrders);

        // Quick sort
        Order[] quickSortedOrders = Arrays.copyOf(orders, orders.length);
        SortingAlgorithms.quickSort(quickSortedOrders, 0, quickSortedOrders.length - 1);
        System.out.println("\nQuick Sorted Orders:");
        displayOrders(quickSortedOrders);
    }

    private static void displayOrders(Order[] orders) {
        for (Order order : orders) {
            System.out.println(order);
        }
    }
}
