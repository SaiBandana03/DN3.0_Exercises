public class BuilderPatternTest {
    public static void main(String[] args) {
        // Create a basic computer with only CPU and RAM
        Computer basicComputer = new Computer.Builder("Intel i5", "8GB")
                .build();
        System.out.println(basicComputer);

        // Create a high-end gaming computer
        Computer gamingComputer = new Computer.Builder("Intel i9", "32GB")
                .setStorage("1TB SSD")
                .setGraphicsCard("NVIDIA RTX 3080")
                .setOperatingSystem("Windows 10")
                .build();
        System.out.println(gamingComputer);

        // Create a mid-range computer with some additional features
        Computer midRangeComputer = new Computer.Builder("Intel i7", "16GB")
                .setStorage("512GB SSD")
                .setOperatingSystem("Linux")
                .build();
        System.out.println(midRangeComputer);
    }
}
