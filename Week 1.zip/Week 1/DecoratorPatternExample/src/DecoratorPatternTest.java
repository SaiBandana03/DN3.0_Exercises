public class DecoratorPatternTest {
    public static void main(String[] args) {
        // Basic Email Notifier
        Notifier emailNotifier = new EmailNotifier();
        emailNotifier.send("Hello via Email!");

        // Email and SMS Notifier
        Notifier smsNotifier = new SMSNotifierDecorator(emailNotifier);
        smsNotifier.send("Hello via Email and SMS!");

        // Email, SMS, and Slack Notifier
        Notifier slackNotifier = new SlackNotifierDecorator(smsNotifier);
        slackNotifier.send("Hello via Email, SMS, and Slack!");
    }
}
