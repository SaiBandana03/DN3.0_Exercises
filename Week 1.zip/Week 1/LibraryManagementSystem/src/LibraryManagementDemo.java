public class LibraryManagementDemo {

    public static void main(String[] args) {
        // Create a Library instance
        Library library = new Library();

        // Add some books (assuming sorted order for binary search)
        library.addBooksSorted(
                new Book(1, "The Great Gatsby", "F. Scott Fitzgerald"),
                new Book(2, "To Kill a Mockingbird", "Harper Lee"),
                new Book(3, "1984", "George Orwell"),
                new Book(4, "Pride and Prejudice", "Jane Austen"),
                new Book(5, "Moby Dick", "Herman Melville"));

        // Display all books
        System.out.println("All Books in the Library:");
        library.displayBooks();

        // Search for a book by title using linear search
        String titleToSearch = "1984";
        System.out.println("\nSearching for book with title '" + titleToSearch + "' using linear search:");
        Book foundBookLinear = library.findBookByTitleLinear(titleToSearch);
        if (foundBookLinear != null) {
            System.out.println("Found: " + foundBookLinear);
        } else {
            System.out.println("Book not found.");
        }

        // Search for a book by title using binary search
        System.out.println("\nSearching for book with title '" + titleToSearch + "' using binary search:");
        Book foundBookBinary = library.findBookByTitleBinary(titleToSearch);
        if (foundBookBinary != null) {
            System.out.println("Found: " + foundBookBinary);
        } else {
            System.out.println("Book not found.");
        }
    }
}
