public class MVCPatternTest {
    public static void main(String[] args) {
        // Create a model
        Student student = new Student("Shreya", 123, "A");

        // Create a view
        StudentView view = new StudentView();

        // Create a controller
        StudentController controller = new StudentController(student, view);

        // Display initial details
        controller.updateView();

        // Update student details
        controller.setStudentName("Dev");
        controller.setStudentGrade("B");

        // Display updated details
        controller.updateView();
    }
}
