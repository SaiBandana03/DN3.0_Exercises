public class SquarePayment {
    public void doTransaction(double amount) {
        System.out.println("Processing payment of $" + amount + " through Square.");
    }
}
