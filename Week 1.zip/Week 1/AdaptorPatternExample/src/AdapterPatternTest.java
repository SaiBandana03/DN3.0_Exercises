public class AdapterPatternTest {
    public static void main(String[] args) {
        // PayPal payment processing
        PayPalPayment payPalPayment = new PayPalPayment();
        PaymentProcessor payPalAdapter = new PayPalAdapter(payPalPayment);
        payPalAdapter.processPayment(150.00);

        // Stripe payment processing
        StripePayment stripePayment = new StripePayment();
        PaymentProcessor stripeAdapter = new StripeAdapter(stripePayment);
        stripeAdapter.processPayment(250.00);

        // Square payment processing
        SquarePayment squarePayment = new SquarePayment();
        PaymentProcessor squareAdapter = new SquareAdapter(squarePayment);
        squareAdapter.processPayment(350.00);
    }
}
