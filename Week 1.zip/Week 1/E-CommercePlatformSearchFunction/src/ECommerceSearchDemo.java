import java.util.Arrays;

public class ECommerceSearchDemo {

    public static void main(String[] args) {
        // Create sample products
        Product[] products = {
                new Product("P005", "Headphones", "Electronics"),
                new Product("P003", "Tablet", "Electronics"),
                new Product("P001", "Laptop", "Computers"),
                new Product("P004", "Smartwatch", "Electronics"),
                new Product("P002", "Smartphone", "Electronics")
        };

        // Sort products by productId for binary search
        Arrays.sort(products, (p1, p2) -> p1.getProductId().compareTo(p2.getProductId()));

        // Linear search
        System.out.println("Linear Search:");
        Product resultLinear = SearchAlgorithms.linearSearch(products, "P003");
        System.out.println(resultLinear != null ? resultLinear : "Product not found");

        // Binary search
        System.out.println("\nBinary Search:");
        Product resultBinary = SearchAlgorithms.binarySearch(products, "P003");
        System.out.println(resultBinary != null ? resultBinary : "Product not found");
    }
}
