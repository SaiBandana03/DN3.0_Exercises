public class TaskManagementDemo {

    public static void main(String[] args) {

        TaskManager manager = new TaskManager();

        Task task1 = new Task(1, "Task 1", "Pending");
        Task task2 = new Task(2, "Task 2", "Completed");
        Task task3 = new Task(3, "Task 3", "In Progress");

        manager.addTask(task1);
        manager.addTask(task2);
        manager.addTask(task3);

        System.out.println("All Tasks:");
        manager.traverseTasks();

        System.out.println("\nSearching for Task with ID 2:");
        Task searchResult = manager.searchTaskById(2);
        System.out.println(searchResult);

        System.out.println("\nDeleting Task with ID 1:");
        manager.deleteTaskById(1);

        System.out.println("\nAll Tasks After Deletion:");
        manager.traverseTasks();
    }
}
