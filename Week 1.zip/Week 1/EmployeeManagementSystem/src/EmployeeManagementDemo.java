public class EmployeeManagementDemo {

    public static void main(String[] args) {
        // Create an EmployeeManager with capacity for 5 employees
        EmployeeManager manager = new EmployeeManager(5);

        // Create sample employees
        Employee emp1 = new Employee(1, "Alice", "Developer", 80000);
        Employee emp2 = new Employee(2, "Bob", "Manager", 90000);
        Employee emp3 = new Employee(3, "Charlie", "Analyst", 70000);
        Employee emp4 = new Employee(4, "David", "Tester", 60000);
        Employee emp5 = new Employee(5, "Eve", "Designer", 75000);

        // Add employees
        manager.addEmployee(emp1);
        manager.addEmployee(emp2);
        manager.addEmployee(emp3);
        manager.addEmployee(emp4);
        manager.addEmployee(emp5);

        // Display all employees
        System.out.println("All Employees:");
        manager.traverseEmployees();

        // Search for an employee by ID
        System.out.println("\nSearching for Employee with ID 3:");
        Employee searchResult = manager.searchEmployeeById(3);
        System.out.println(searchResult);

        // Delete an employee by ID
        System.out.println("\nDeleting Employee with ID 2:");
        manager.deleteEmployeeById(2);

        // Display all employees after deletion
        System.out.println("\nAll Employees After Deletion:");
        manager.traverseEmployees();
    }
}
